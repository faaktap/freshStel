<template>
  <span>
     <v-icon
      v-if="displayType == 'icon'"
      :small="small"
      :large="large"
      :x-small="xSmall"
      :color="color"
      :title="name"
    >
     {{ iconName }}
    </v-icon>

    <template v-if="iconName == 'all'">
     <v-icon v-for="i in pwIcons" :key="i.icon" :title="i.icon" large>
      {{ i.icon }}
     </v-icon>
    </template>

    <v-img
      v-else
      :src="iconName"
      :max-width="maxWidth"
      :width="maxWidth"
      :height="maxWidth"
      :title="name"
      contain
    />
    :::T:{{ iconName }} {{ displayType }}<!-- m={{ maxWidth }} l={{ large }} s={{ small }} xs={{ xSmall }} -->
  </span>
</template>

<script>
// here we must import each icon we want to use
// see vuetify.js to change mdi to mdiSvg and read article (https://stackoverflow.com/questions/57552261/vuetifyjs-adding-only-used-icons-to-build)
export default {
  name: "PIcon",
  props: {
    name: { default: "mdi-kettle" },
    large: { type: Boolean, default: false },
    small: { type: Boolean, default: false },
    xSmall: { type: Boolean, default: false },
    width: { default: 0 },
    color: { default: "black" },
  },
  data: () => ({
    iconName: "mdi-coffee",
    pwIcons: [
{ icon:'mdi-account', type: 'icon', alias: 'account'},
{ icon:'mdi-account-box', type: 'icon', alias: 'account-box'},
{ icon:'mdi-account-circle ', type: 'icon', alias: 'account-circle '},
{ icon:'mdi-account-edit', type: 'icon', alias: 'account-edit'},
{ icon:'mdi-account-network', type: 'icon', alias: 'account-network'},
{ icon:'mdi-account-question', type: 'icon', alias: 'account-question'},
{ icon:'mdi-account-question-outline', type: 'icon', alias: 'account-question-outline'},
{ icon:'mdi-alpha-g-box', type: 'icon', alias: 'alpha-g-box'},
{ icon:'mdi-alpha-n-circle', type: 'icon', alias: 'alpha-n-circle'},
{ icon:'mdi-ambulance,', type: 'icon', alias: 'ambulance,'},
{ icon:'mdi-application', type: 'icon', alias: 'application'},
{ icon:'mdi-arrow-collapse', type: 'icon', alias: 'arrow-collapse'},
{ icon:'mdi-arrow-expand', type: 'icon', alias: 'arrow-expand'},
{ icon:'mdi-arrow-right-circle-outline', type: 'icon', alias: 'arrow-right-circle-outline'},
{ icon:'mdi-arrow-up', type: 'icon', alias: 'arrow-up'},
{ icon:'mdi-arrow-up-circle', type: 'icon', alias: 'arrow-up-circle'},
{ icon:'mdi-attachment ', type: 'icon', alias: 'attachment '},
{ icon:'mdi-backspace', type: 'icon', alias: 'backspace'},
{ icon:'mdi-badge-account-outline', type: 'icon', alias: 'badge-account-outline'},
{ icon:'mdi-bomb-off', type: 'icon', alias: 'bomb-off'},
{ icon:'mdi-bookshelf', type: 'icon', alias: 'bookshelf'},
{ icon:'mdi-brain', type: 'icon', alias: 'brain'},
{ icon:'mdi-bread-slice', type: 'icon', alias: 'bread-slice'},
{ icon:'mdi-calculator-variant', type: 'icon', alias: 'calculator-variant'},
{ icon:'mdi-calendar', type: 'icon', alias: 'calendar'},
{ icon:'mdi-calendar-month-outline', type: 'icon', alias: 'calendar-month-outline'},
{ icon:'mdi-calendar-today', type: 'icon', alias: 'calendar-today'},
{ icon:'mdi-camera', type: 'icon', alias: 'camera'},
{ icon:'mdi-camera-image', type: 'icon', alias: 'camera-image'},
{ icon:'mdi-cancel ', type: 'icon', alias: 'cancel '},
{ icon:'mdi-card', type: 'icon', alias: 'card'},
{ icon:'mdi-card-search', type: 'icon', alias: 'card-search'},
{ icon:'mdi-cards-diamond', type: 'icon', alias: 'cards-diamond'},
{ icon:'mdi-cellphone-sound', type: 'icon', alias: 'cellphone-sound'},
{ icon:'mdi-chair-school', type: 'icon', alias: 'chair-school'},
{ icon:'mdi-chart-timeline', type: 'icon', alias: 'chart-timeline'},
{ icon:'mdi-check-decagram', type: 'icon', alias: 'check-decagram'},
{ icon:'mdi-checkbox-blank', type: 'icon', alias: 'checkbox-blank'},
{ icon:'mdi-checkbox-blank-outline', type: 'icon', alias: 'checkbox-blank-outline'},
{ icon:'mdi-chevron-left', type: 'icon', alias: 'chevron-left'},
{ icon:'mdi-chevron-right', type: 'icon', alias: 'chevron-right'},
{ icon:'mdi-chevron-up', type: 'icon', alias: 'chevron-up'},
{ icon:'mdi-circle-edit-outline', type: 'icon', alias: 'circle-edit-outline'},
{ icon:'mdi-clipboard-edit-outline', type: 'icon', alias: 'clipboard-edit-outline'},
{ icon:'mdi-close', type: 'icon', alias: 'close'},
{ icon:'mdi-close-box', type: 'icon', alias: 'close-box'},
{ icon:'mdi-close-circle-outline', type: 'icon', alias: 'close-circle-outline'},
{ icon:'mdi-cloud-upload', type: 'icon', alias: 'cloud-upload'},
{ icon:'mdi-code-json', type: 'icon', alias: 'code-json'},
{ icon:'mdi-coffee', type: 'icon', alias: 'coffee'},
{ icon:'mdi-coffin', type: 'icon', alias: 'coffin'},
{ icon:'mdi-content-duplicate', type: 'icon', alias: 'content-duplicate'},
{ icon:'mdi-content-save ', type: 'icon', alias: 'content-save '},
{ icon:'mdi-cupcake', type: 'icon', alias: 'cupcake'},
{ icon:'mdi-database', type: 'icon', alias: 'database'},
{ icon:'mdi-database-edit', type: 'icon', alias: 'database-edit'},
{ icon:'mdi-database-export', type: 'icon', alias: 'database-export'},
{ icon:'mdi-database-minus ', type: 'icon', alias: 'database-minus '},
{ icon:'mdi-database-plus ', type: 'icon', alias: 'database-plus '},
{ icon:'mdi-database-refresh', type: 'icon', alias: 'database-refresh'},
{ icon:'mdi-decagram', type: 'icon', alias: 'decagram'},
{ icon:'mdi-delete', type: 'icon', alias: 'delete'},
{ icon:'mdi-delete-empty', type: 'icon', alias: 'delete-empty'},
{ icon:'mdi-delete-variant', type: 'icon', alias: 'delete-variant'},
{ icon:'mdi-delete ', type: 'icon', alias: 'delete '},
{ icon:'mdi-disc', type: 'icon', alias: 'disc'},
{ icon:'mdi-dots-vertical', type: 'icon', alias: 'dots-vertical'},
{ icon:'mdi-drag-horizontal-variant', type: 'icon', alias: 'drag-horizontal-variant'},
{ icon:'mdi-drawing', type: 'icon', alias: 'drawing'},
{ icon:'mdi-email-newsletter', type: 'icon', alias: 'email-newsletter'},
{ icon:'mdi-email-off-outline', type: 'icon', alias: 'email-off-outline'},
{ icon:'mdi-email ', type: 'icon', alias: 'email '},
{ icon:'mdi-emoticon-wink-outline', type: 'icon', alias: 'emoticon-wink-outline'},
{ icon:'mdi-exclamation', type: 'icon', alias: 'exclamation'},
{ icon:'mdi-eye', type: 'icon', alias: 'eye'},
{ icon:'mdi-eye-off', type: 'icon', alias: 'eye-off'},
{ icon:'mdi-face-outline', type: 'icon', alias: 'face-outline'},
{ icon:'mdi-facebook', type: 'icon', alias: 'facebook'},
{ icon:'mdi-file', type: 'icon', alias: 'file'},
{ icon:'mdi-file-cad', type: 'icon', alias: 'file-cad'},
{ icon:'mdi-file-check ', type: 'icon', alias: 'file-check '},
{ icon:'mdi-file-document', type: 'icon', alias: 'file-document'},
{ icon:'mdi-file-document-edit-outline', type: 'icon', alias: 'file-document-edit-outline'},
{ icon:'mdi-file-excel', type: 'icon', alias: 'file-excel'},
{ icon:'mdi-file-excel-outline', type: 'icon', alias: 'file-excel-outline'},
{ icon:'mdi-file-export', type: 'icon', alias: 'file-export'},
{ icon:'mdi-file-image', type: 'icon', alias: 'file-image'},
{ icon:'mdi-file-image-outline', type: 'icon', alias: 'file-image-outline'},
{ icon:'mdi-file-music', type: 'icon', alias: 'file-music'},
{ icon:'mdi-file-pdf', type: 'icon', alias: 'file-pdf'},
{ icon:'mdi-file-pdf-box', type: 'icon', alias: 'file-pdf-box'},
{ icon:'mdi-file-powerpoint', type: 'icon', alias: 'file-powerpoint'},
{ icon:'mdi-file-powerpoint-outline', type: 'icon', alias: 'file-powerpoint-outline'},
{ icon:'mdi-file-question-outline', type: 'icon', alias: 'file-question-outline'},
{ icon:'mdi-file-search', type: 'icon', alias: 'file-search'},
{ icon:'mdi-file-upload', type: 'icon', alias: 'file-upload'},
{ icon:'mdi-file-video-outline', type: 'icon', alias: 'file-video-outline'},
{ icon:'mdi-file-word-outline', type: 'icon', alias: 'file-word-outline'},
{ icon:'mdi-folder', type: 'icon', alias: 'folder'},
{ icon:'mdi-folder-edit', type: 'icon', alias: 'folder-edit'},
{ icon:'mdi-folder-key', type: 'icon', alias: 'folder-key'},
{ icon:'mdi-folder-move', type: 'icon', alias: 'folder-move'},
{ icon:'mdi-folder-move-outline', type: 'icon', alias: 'folder-move-outline'},
{ icon:'mdi-folder-open', type: 'icon', alias: 'folder-open'},
{ icon:'mdi-folder-plus', type: 'icon', alias: 'folder-plus'},
{ icon:'mdi-folder-plus-outline', type: 'icon', alias: 'folder-plus-outline'},
{ icon:'mdi-folder-zip', type: 'icon', alias: 'folder-zip'},
{ icon:'mdi-folder-zip-outline', type: 'icon', alias: 'folder-zip-outline'},
{ icon:'mdi-font', type: 'icon', alias: 'font'},
{ icon:'mdi-food-apple', type: 'icon', alias: 'food-apple'},
{ icon:'mdi-format-color-fill', type: 'icon', alias: 'format-color-fill'},
{ icon:'mdi-format-list-checkbox', type: 'icon', alias: 'format-list-checkbox'},
{ icon:'mdi-fountain-pen-tip', type: 'icon', alias: 'fountain-pen-tip'},
{ icon:'mdi-function', type: 'icon', alias: 'function'},
{ icon:'mdi-glass-wine ', type: 'icon', alias: 'glass-wine '},
{ icon:'mdi-glasses', type: 'icon', alias: 'glasses'},
{ icon:'mdi-golf', type: 'icon', alias: 'golf'},
{ icon:'mdi-google-classroom', type: 'icon', alias: 'google-classroom'},
{ icon:'mdi-group', type: 'icon', alias: 'group'},
{ icon:'mdi-hamburger', type: 'icon', alias: 'hamburger'},
{ icon:'mdi-hard-hat', type: 'icon', alias: 'hard-hat'},
{ icon:'mdi-harddisk', type: 'icon', alias: 'harddisk'},
{ icon:'mdi-head', type: 'icon', alias: 'head'},
{ icon:'mdi-head-outline', type: 'icon', alias: 'head-outline'},
{ icon:'mdi-heart', type: 'icon', alias: 'heart'},
{ icon:'mdi-heart-box', type: 'icon', alias: 'heart-box'},
{ icon:'mdi-help', type: 'icon', alias: 'help'},
{ icon:'mdi-help-circle-outline ', type: 'icon', alias: 'help-circle-outline '},
{ icon:'mdi-history', type: 'icon', alias: 'history'},
{ icon:'mdi-home', type: 'icon', alias: 'home'},
{ icon:'mdi-home-circle', type: 'icon', alias: 'home-circle'},
{ icon:'mdi-home-edit', type: 'icon', alias: 'home-edit'},
{ icon:'mdi-home-outline', type: 'icon', alias: 'home-outline'},
{ icon:'mdi-hospital-building', type: 'icon', alias: 'hospital-building'},
{ icon:'mdi-human', type: 'icon', alias: 'human'},
{ icon:'mdi-human-greeting', type: 'icon', alias: 'human-greeting'},
{ icon:'mdi-human-male-board', type: 'icon', alias: 'human-male-board'},
{ icon:'mdi-id-card', type: 'icon', alias: 'id-card'},
{ icon:'mdi-identifier', type: 'icon', alias: 'identifier'},
{ icon:'mdi-image', type: 'icon', alias: 'image'},
{ icon:'mdi-image-area', type: 'icon', alias: 'image-area'},
{ icon:'mdi-image-move', type: 'icon', alias: 'image-move'},
{ icon:'mdi-info', type: 'icon', alias: 'info'},
{ icon:'mdi-information', type: 'icon', alias: 'information'},
{ icon:'mdi-information-variant', type: 'icon', alias: 'information-variant'},
{ icon:'mdi-instagram', type: 'icon', alias: 'instagram'},
{ icon:'mdi-kabaddi', type: 'icon', alias: 'kabaddi'},
{ icon:'mdi-kettle', type: 'icon', alias: 'kettle'},
{ icon:'mdi-kettle-steam', type: 'icon', alias: 'kettle-steam'},
{ icon:'mdi-kettle-steam-outline', type: 'icon', alias: 'kettle-steam-outline'},
{ icon:'mdi-keyboard-backspace', type: 'icon', alias: 'keyboard-backspace'},
{ icon:'mdi-label', type: 'icon', alias: 'label'},
{ icon:'mdi-language-html5', type: 'icon', alias: 'language-html5'},
{ icon:'mdi-language-markdown', type: 'icon', alias: 'language-markdown'},
{ icon:'mdi-link', type: 'icon', alias: 'link'},
{ icon:'mdi-link-box', type: 'icon', alias: 'link-box'},
{ icon:'mdi-location-exit', type: 'icon', alias: 'location-exit'},
{ icon:'mdi-lock-reset', type: 'icon', alias: 'lock-reset'},
{ icon:'mdi-lock ', type: 'icon', alias: 'lock '},
{ icon:'mdi-login', type: 'icon', alias: 'login'},
{ icon:'mdi-logout', type: 'icon', alias: 'logout'},
{ icon:'mdi-magnify', type: 'icon', alias: 'magnify'},
{ icon:'mdi-map-marker', type: 'icon', alias: 'map-marker'},
{ icon:'mdi-marker', type: 'icon', alias: 'marker'},
{ icon:'mdi-marker-check', type: 'icon', alias: 'marker-check'},
{ icon:'mdi-menu', type: 'icon', alias: 'menu'},
{ icon:'mdi-menu-down', type: 'icon', alias: 'menu-down'},
{ icon:'mdi-minus', type: 'icon', alias: 'minus'},
{ icon:'mdi-minus-box', type: 'icon', alias: 'minus-box'},
{ icon:'mdi-moon-waning-crescent', type: 'icon', alias: 'moon-waning-crescent'},
{ icon:'mdi-movie', type: 'icon', alias: 'movie'},
{ icon:'mdi-music-note', type: 'icon', alias: 'music-note'},
{ icon:'mdi-nature-people', type: 'icon', alias: 'nature-people'},
{ icon:'mdi-navigation', type: 'icon', alias: 'navigation'},
{ icon:'mdi-nodejs', type: 'icon', alias: 'nodejs'},
{ icon:'mdi-note-text', type: 'icon', alias: 'note-text'},
{ icon:'mdi-office-building', type: 'icon', alias: 'office-building'},
{ icon:'mdi-office-building-marker-outline', type: 'icon', alias: 'office-building-marker-outline'},
{ icon:'mdi-open-in-new', type: 'icon', alias: 'open-in-new'},
{ icon:'mdi-pause', type: 'icon', alias: 'pause'},
{ icon:'mdi-pen-plus', type: 'icon', alias: 'pen-plus'},
{ icon:'mdi-pencil', type: 'icon', alias: 'pencil'},
{ icon:'mdi-pencil-outline', type: 'icon', alias: 'pencil-outline'},
{ icon:'mdi-percent', type: 'icon', alias: 'percent'},
{ icon:'mdi-phone', type: 'icon', alias: 'phone'},
{ icon:'mdi-play', type: 'icon', alias: 'play'},
{ icon:'mdi-plus', type: 'icon', alias: 'plus'},
{ icon:'mdi-plus-box-outline', type: 'icon', alias: 'plus-box-outline'},
{ icon:'mdi-presentation', type: 'icon', alias: 'presentation'},
{ icon:'mdi-print', type: 'icon', alias: 'print'},
{ icon:'mdi-printer', type: 'icon', alias: 'printer'},
{ icon:'mdi-printer-wireless', type: 'icon', alias: 'printer-wireless'},
{ icon:'mdi-propane-tank-outline', type: 'icon', alias: 'propane-tank-outline'},
{ icon:'mdi-qrcode-scan', type: 'icon', alias: 'qrcode-scan'},
{ icon:'mdi-refresh ', type: 'icon', alias: 'refresh '},
{ icon:'mdi-reload', type: 'icon', alias: 'reload'},
{ icon:'mdi-rename-box', type: 'icon', alias: 'rename-box'},
{ icon:'mdi-school', type: 'icon', alias: 'school'},
{ icon:'mdi-screw-lag', type: 'icon', alias: 'screw-lag'},
{ icon:'mdi-script', type: 'icon', alias: 'script'},
{ icon:'mdi-script-text-outline', type: 'icon', alias: 'script-text-outline'},
{ icon:'mdi-seat-legroom-reduced', type: 'icon', alias: 'seat-legroom-reduced'},
{ icon:'mdi-select', type: 'icon', alias: 'select'},
{ icon:'mdi-select-color', type: 'icon', alias: 'select-color'},
{ icon:'mdi-select-group', type: 'icon', alias: 'select-group'},
{ icon:'mdi-send', type: 'icon', alias: 'send'},
{ icon:'mdi-share-variant', type: 'icon', alias: 'share-variant'},
{ icon:'mdi-shield-plus', type: 'icon', alias: 'shield-plus'},
{ icon:'mdi-shield-plus-outline', type: 'icon', alias: 'shield-plus-outline'},
{ icon:'mdi-shopping', type: 'icon', alias: 'shopping'},
{ icon:'mdi-silverware ', type: 'icon', alias: 'silverware '},
{ icon:'mdi-sitemap', type: 'icon', alias: 'sitemap'},
{ icon:'mdi-spade', type: 'icon', alias: 'spade'},
{ icon:'mdi-spider', type: 'icon', alias: 'spider'},
{ icon:'mdi-star', type: 'icon', alias: 'star'},
{ icon:'mdi-star-four-points-outline', type: 'icon', alias: 'star-four-points-outline'},
{ icon:'mdi-star-outline', type: 'icon', alias: 'star-outline'},
{ icon:'mdi-star-three-points-outline', type: 'icon', alias: 'star-three-points-outline'},
{ icon:'mdi-star ', type: 'icon', alias: 'star '},
{ icon:'mdi-table-plus', type: 'icon', alias: 'table-plus'},
{ icon:'mdi-table-refresh', type: 'icon', alias: 'table-refresh'},
{ icon:'mdi-teach', type: 'icon', alias: 'teach'},
{ icon:'mdi-test-tube', type: 'icon', alias: 'test-tube'},
{ icon:'mdi-testtube', type: 'icon', alias: 'testtube'},
{ icon:'mdi-text', type: 'icon', alias: 'text'},
{ icon:'mdi-text-box', type: 'icon', alias: 'text-box'},
{ icon:'mdi-text-subject', type: 'icon', alias: 'text-subject'},
{ icon:'mdi-theme-light-dark', type: 'icon', alias: 'theme-light-dark'},
{ icon:'mdi-though-bubble-outline', type: 'icon', alias: 'though-bubble-outline'},
{ icon:'mdi-thumb-up ', type: 'icon', alias: 'thumb-up '},
{ icon:'mdi-timetable', type: 'icon', alias: 'timetable'},
{ icon:'mdi-tooltip-edit', type: 'icon', alias: 'tooltip-edit'},
{ icon:'mdi-tooltip-text-outline', type: 'icon', alias: 'tooltip-text-outline'},
{ icon:'mdi-toothbrush-paste', type: 'icon', alias: 'toothbrush-paste'},
{ icon:'mdi-trash-can-outline', type: 'icon', alias: 'trash-can-outline'},
{ icon:'mdi-trophy', type: 'icon', alias: 'trophy'},
{ icon:'mdi-trophy-award', type: 'icon', alias: 'trophy-award'},
{ icon:'mdi-twitter', type: 'icon', alias: 'twitter'},
{ icon:'mdi-typewriter', type: 'icon', alias: 'typewriter'},
{ icon:'mdi-update', type: 'icon', alias: 'update'},
{ icon:'mdi-upload ', type: 'icon', alias: 'upload '},
{ icon:'mdi-video', type: 'icon', alias: 'video'},
{ icon:'mdi-view-agenda-outline', type: 'icon', alias: 'view-agenda-outline'},
{ icon:'mdi-view-compact ', type: 'icon', alias: 'view-compact '},
{ icon:'mdi-view-day', type: 'icon', alias: 'view-day'},
{ icon:'mdi-view-list ', type: 'icon', alias: 'view-list '},
{ icon:'mdi-viewday', type: 'icon', alias: 'viewday'},
{ icon:'mdi-virus', type: 'icon', alias: 'virus'},
{ icon:'mdi-volume-mute', type: 'icon', alias: 'volume-mute'},
{ icon:'mdi-vote', type: 'icon', alias: 'vote'},
{ icon:'mdi-vote-outline', type: 'icon', alias: 'vote-outline'},
{ icon:'mdi-wallpaper', type: 'icon', alias: 'wallpaper'},
{ icon:'mdi-wardrobe-outline ', type: 'icon', alias: 'wardrobe-outline '},
{ icon:'mdi-wardrobe ', type: 'icon', alias: 'wardrobe '},
{ icon:'mdi-warehouse', type: 'icon', alias: 'warehouse'},
{ icon:'mdi-washing-machine', type: 'icon', alias: 'washing-machine'},
{ icon:'mdi-watch-export-variant', type: 'icon', alias: 'watch-export-variant'},
{ icon:'mdi-water-polo', type: 'icon', alias: 'water-polo'},
{ icon:'mdi-weather-windy', type: 'icon', alias: 'weather-windy'},
{ icon:'mdi-web-clock', type: 'icon', alias: 'web-clock'},
{ icon:'mdi-weight-kilogram', type: 'icon', alias: 'weight-kilogram'},
{ icon:'mdi-wifi', type: 'icon', alias: 'wifi'},
{ icon:'mdi-wikipedia', type: 'icon', alias: 'wikipedia'},
{ icon:'mdi-wind-turbine', type: 'icon', alias: 'wind-turbine'},
{ icon:'mdi-window-close', type: 'icon', alias: 'window-close'},
{ icon:'mdi-window-maximize', type: 'icon', alias: 'window-maximize'},
{ icon:'mdi-window-open', type: 'icon', alias: 'window-open'},
{ icon:'mdi-wiper', type: 'icon', alias: 'wiper'},
{ icon:'mdi-yoga', type: 'icon', alias: 'yoga'}    ],
    displayType: "icon",
  }),
  computed: {
    maxWidth() {
      // console.log(this.large, this.small, this.xSmall);
      if (this.displayType == "icon") return "";
      if (this.displayType == "all") return "";
      if (this.width) return this.width;
      if (this.large == "") return 50;
      if (this.small == "") return 30;
      if (this.xSmall == "") return 20;
      return 40;
    },
  },
  methods: {
    check() {
      // console.log(
      //   "we come into check with ",
      //   this.name,
      //   this.name.indexOf("mdi") > -1
      // );
      if (this.name.indexOf("mdi") > -1) return this.name;
      if (this.name == 'all') { this.displayType = 'all'; return this.name;}

      let icon = "", displayType = "";
      this.pwIcons.forEach((pw) => {
        // console.log(pw.alias.toLowerCase(), this.name.toLocaleLowerCase());
        if (pw.alias.toLowerCase() == this.name.toLocaleLowerCase()) {
          displayType = pw.type;
          icon = pw.icon;
        }
      });
      if (displayType && icon) {
        this.displayType = displayType;
        return icon;
      }
      this.displayType = "icon";
      return "mdi-screw-lag";
    },
  },
  mounted() {
    this.iconName = this.check();
  },
  watch: {
    name(nn, oo) {
      console.log("wath name,", oo, nn);
      this.iconName = this.check();
    },
  },
};
</script>
