<template>
<div>
<v-container fluid v-if="['admin','teacher'].includes(getZml.login.type) == false">
    You are not logged in, or you are not a teacher!
</v-container>

<v-container v-else fluid>
 <v-toolbar  dense  row  wrap>
    Student Class List
        <span v-if="!studentList.length"> - (Select a class below) </span>
        <span v-else> : {{this.gradeClass.g}} -  {{this.gradeClass.c}} </span>
    <v-spacer></v-spacer>
    <!-- <base-tool-button
       v-if="studentList.length"
       icon="mdi-select-group"
       class="mr-2"
       title="Click to view attendance list"
       xxcolor="green"
       @click="attendancePrep"
    >
      ATTENDANCE
    </base-tool-button> -->
    <base-tool-button
       v-if="studentList.length"
       icon="mdi-file-export"
       class="mr-2"
       title="Click to build an export list."
       @click="showListPrint=true"
    >
     EXPORT/PRINT
    </base-tool-button>
    <base-tool-button
       v-if="studentList.length"
       icon="mdi-toothbrush-paste"
       class="mr-2"
       title="Click to build a list of students with their photos."
       @click="showPhotoList=!showPhotoList"
    >
      SHOW PHOTO
    </base-tool-button>
   <base-tool-button v-if="studentList.length"
        title="Trying to get images to print"
        @click="doPrint()"
    >
     T
    </base-tool-button>
 </v-toolbar>

</v-container>
<v-container class="mt-2" fluid>

 <v-row>
  <v-col cols="12">
   <student-grade v-model="gradeClass" gc="gradeClass" />
   <pick-attendance
    v-if="studentList.length && showAttendance == true"
    title="Pick Attendance Parameters"
    :gradeClass="gradeClass"
    @attendanceSelected="attSelected"
   />
  </v-col>
 </v-row>

 <v-row>
  <v-col cols="12" v-if="studentList.length">
   <v-card color="gray lighten-3" class="ma-2" id="x12345">
    <v-card-title class="heading text-center">
      {{ classListHeader }} (#{{studentList.length}}) {{ title }}
     </v-card-title>
    <v-card-text>
      <v-row>
        <v-col cols="6" md="4" lg="3"
               v-for="(s,index) in studentList"
              :key="s.studentid">
          <v-card :color="studentCardColor(s.studentid)"
                  class="ma-1 pl-2"
                  @click="showStudent(index)"
                  @mouseout="hoverStart = null; hover = null"
                  @mouseover="hoverStart = 'R' + s.studentid">
            <v-layout>
             <v-flex xs1 class="ml-2"> {{ index+1 }}  </v-flex>
             <v-flex xs3 v-show="showPhotoList==true">
              <z-show name="studentphoto" :id="s.studentid" />
              <!-- <v-img :src="'https://kuiliesonline.co.za/api/candid/candidates.php?task=photo&studentno=' + s.studentid"
                      height="100"
                      contain
                     :title="s.studentid" /> -->
             </v-flex>
             <v-flex xs8 class="ma-2">
              {{ s.surname }}, {{ s.firstname}}
             </v-flex>
             <div class="float-right"
                @mouseover="hover=s.studentid"
                v-show="hoverStart == 'R' + s.studentid">
                 <v-icon small color="gold darken-1" class="ma-1"> mdi-email </v-icon>
             </div>
            </v-layout>
          </v-card>
          <div v-if="hover == s.studentid">
              <v-card v-for="e in showEmails(s.studentid)"
                   :key="e"
                    color="gold lighten-1"
                    class="ma-2 pa-2">
                {{ e }}
            </v-card>
          </div>
        </v-col>
      </v-row>
     </v-card-text>
     <v-card-actions>
     </v-card-actions>
    </v-card>
   </v-col>
  </v-row>

<!-- <v-container fluid v-if="getZml.login.isAuthenticated && getZml.login.username=='WER'">
  (werner) studentList  :
  <div v-for="s in studentList" :key="s.studentid">
  <br><small>{{ s }}</small>
  </div>
</v-container> -->

<v-dialog v-model="showListPrint" width="auto " :fullscreen="$vuetify.breakpoint.smAndDown" scrollable>
   <zml-close-button @btn-click="showListPrint = !showListPrint" />
  <front-json-to-csv v-if="studentList"
                    :jsonData="studentList"
                    :csvTitle="classListHeader"
                    @hideModal="showListPrint=false">
   <v-btn>
      Download with custom title
   </v-btn>
  </front-json-to-csv>
</v-dialog>

 <v-dialog v-model="showStudentCard"  max-width="650" :fullscreen="$vuetify.breakpoint.smAndDown" :scrollable="false">
   <zml-close-button @btn-click="showStudentCard = false" />
   <student-name-card :studentList="singleStudent" />
 </v-dialog>

</v-container>
</div>
</template>

<script>
//import { doPrint } from "@/api/DoPrint"
//import { printJSON,printJSONBig } from "@/api/zmlPrint.js"
import { printJSON } from "@/api/zmlPrint.js"
import { getters } from "@/api/store"
import { zmlConfig } from '@/api/constants.js';
import { zmlFetch } from '@/api/zmlFetch';
import StudentGrade from '@/components/student/StudentGrade'
import StudentNameCard from '@/components/student/StudentNameCard.vue'
import PickAttendance from '@/components/student/PickAttendance.vue'
import FrontJsonToCsv from '@/api/csv/FrontJsonToCsv.vue'
import zmlCloseButton from '@/components/zmlCloseButton.vue'
import BaseToolButton from '@/views/new/base/BaseToolButton.vue'
import ZShow from '@/components/base/ZShow.vue'


export default {
    name:"StudentClass",
    props:["title","gc"],
    components:{
        StudentGrade
       ,FrontJsonToCsv
       ,zmlCloseButton
       ,StudentNameCard
       ,BaseToolButton
       ,PickAttendance
       ,ZShow
    },
    computed: {},
    data: () => ({
        getZml: getters.getState({ object: "gZml" }),
        gradeClass:{},
        studentList:[],
        singleStudent:{data:''},
        showStudentCard:null,
        showPhotoList:null,
        hover:null,
        hoverStart:null,
        showListPrint:false,
        showAttendance:false,
        classListHeader:'',
        attendanceList:[],
    }),
    methods:{
      doPrint() {
         let head = [{text:'id', value:'studentid'},{test:"surname", value:'surname'},
                     {text:"firstname", value:"firstname"}]
        printJSON(this.studentList, head, 'Student List : ' + this.gradeClass.g + this.gradeClass.c)
      },
      attendancePrep() {
        this.showAttendance = !this.showAttendance
        if (this.showAttendance == false) {
          this.attendanceList.length = 0
          this.classListHeader = `Student Attendance List for ${this.gradeClass.g}${this.gradeClass.c}`
        }
      },
      attSelected(aList,aProp) {
        //this.showAttendance = false
        this.attendanceList = aList
        this.classListHeader = `Student List for ${this.gradeClass.g}${this.gradeClass.c} \
                                Room (${aProp.location}) Period (${aProp.period}) - ${aProp.staff}`
        this.$cs.l('use',aList,' to do a fetch on all students', aProp)
      },
      studentCardColor(id) {
        if (this.attendanceList.length == 0) return 'gray lighten-4'
        this.$cs.l('List=',this.attendanceList)
        if (this.attendanceList.findIndex(a => a.studentid == id) > -1) {
          return "green darken-1"
        } else {
          return "red lighten-2"
        }
      },
      showEmails(id) {
        let em = this.studentList.find(e => e.studentid == id)
        this.$cs.l('show emails',em)
        if (!em.emails) {
          return ["No Emails Found"]
        }
        return em.emails.split(',')
      },
      loadData(response) {
        this.classListHeader = "Student List for Class " + this.gradeClass.g + ' ' + this.gradeClass.c
        this.studentList = response
      },
      loadError(error) {
        alert('S.C.' + error)
      },
      classListLoad() {
        let ts = {}
        ts.task = 'PlainSql'
        ts.sql = `SELECT studentid, surname, firstname, grade, gclass\
         , idno, GROUP_CONCAT(email) emails\
         FROM dkhs_student s\
         left join m_subscriber m on s.studentid = m.impnumber and m.outid is null\
         where grade like '${this.gradeClass.g}'\
         and gclass = '${this.gradeClass.c}'\
         group by studentid, surname, firstname, grade, gclass, idno\
         order by s.surname, s.firstname`
        ts.api = zmlConfig.apiDKHS
        ts.grade = this.gradeClass.g
        ts.class = this.gradeClass.c
        zmlFetch(ts, this.loadData, this.loadError);

      },
      showStudent(idx) {
        this.singleStudent.data = this.studentList[idx]
        this.showStudentCard = true
      }
     },
    mounted() {
      this.$cs.l('SC(mounted)1 : ', this.$options.name)
      this.$cs.l('SC(mounted)2 : ', this.$router.params)
      this.$cs.l('SC(mounted)3 : ', this.gc)
      if (this.gc && this.gc.c && this.gc.g) {
        // {"g": "G08", "c": "E1" }
        this.$cs.l('gc exist', this.gc)
        this.gradeClass = {g:this.gc.g, c:this.gc.c}
      }
    },
    watch: {
      gradeClass() {
        if (this.gradeClass) {
          this.classListLoad(this.gradeClass)
        }
      }
    }
}
</script>