<template>
<!--     xmlns="http://www.w3.org/2000/svg"
     xml:space="preserve" version="1.1" shape-rendering="geometricPrecision"
     text-rendering="geometricPrecision" image-rendering="optimizeQuality" fill-rule="evenodd" clip-rule="evenodd">
-->
<svg :view-box.camel="viewBox" :width="width" :height="height">
 <g id="ManSittingWithLaptop">
  <path id="RightArm" fill="white" stroke="black" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="22.9256" d="M214 200l41 -3c0,0 8,107 0,118 -8,11 -45,25 -45,25l1 -36 8 -2 -5 -101 0 0z"/>
  <path id="LeftArm" fill="white" stroke="black" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="22.9256" d="M50 208l-37 -2c0,0 -12,106 -4,117 8,11 45,15 45,15l-1 -27 -8 -2 5 -101 0 0z"/>
  <path id="Shirt" fill="#0080BF" stroke="#101010" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="22.9256" d="M46 227l-41 -12c1,0 1,-1 1,-2 0,-1 -1,-2 -2,-2 -1,0 -2,1 -2,2 0,1 0,2 1,2l8 -40c4,-20 19,-35 37,-40l86 -21 1 0 84 21c19,5 34,21 37,41l7 39c0,1 -1,2 -2,3l-44 13 5 92c0,1 0,2 -1,2 -2,1 -58,35 -88,35l-2 0c-29,-1 -82,-23 -84,-24 1,0 1,-1 1,-2 0,-1 -1,-2 -2,-2 -1,0 -2,1 -2,2 0,1 1,2 1,2l0 -104 2 -5 0 0z"/>
  <ellipse id="Logo" fill="black" stroke="black" stroke-width="1" stroke-linejoin="round" stroke-miterlimit="22.9256" transform="matrix(0.50547 0.07446 -0.08451 0.57374 130.298 213.524)" rx="67" ry="60"/>
  <g id="Plane">
   <path fill="white" fill-rule="nonzero" d="M168 214l4 -5 -4 -9 -13 10 -2 -6 11 -13 -3 -8c1,-1 2,-1 3,-1l0 0c0,0 1,0 1,0 1,0 2,1 2,2l3 8 17 2 2 6 -16 2 3 9 6 1 2 5 -8 1 -1 0 -1 1 -6 5 -2 -5 1 -5 0 0z"/>
  </g>
  <path id="Head" fill="white" stroke="black" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="22.9256" d="M170 105c0,4 -7,26 -40,27 -18,1 -37,-23 -38,-27l-3 -21 0 0c-6,0 -10,-5 -10,-10l0 -6c0,-5 3,-9 8,-10 2,-26 21,-56 44,-56 23,0 42,31 45,56l3 0c3,0 4,2 4,5l0 12c0,5 -4,10 -10,10l-3 21 0 0 0 0z"/>
  <g id="Laptop">
   <path fill="#C9C9C9" stroke="black" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="22.9256" d="M215 371l-165 0c-5,0 -9,-4 -10,-9l-13 -93 187 0 -13 93c-3,2 -6,6 -6,10 0,6 4,11 10,11 5,0 10,-5 10,-11 0,-4 -2,-8 -6,-10l6 9 0 0z"/>
  </g>
 </g>
</svg>
</template>

<script>
export default {
    name:'ManSittingWithLaptop',
    props: {
      width: {
        type: Number,
        default: 253
      },
      height: {
        type: Number,
        default: 383
      }
   },
   data: () => ({
      vbx: 0,
      vby: 0,
      vbw: 250,
      vbh: 364,
   }),
   computed: {
    viewBox() {
      const {vbx,vby,vbw,vbh} = this.$data;
      return [vbx,vby,vbw,vbh].join(' ');

    },
}
}
</script>
<style scoped>

</style>
