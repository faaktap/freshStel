<template>
     <v-container class="py-8 px-6" fluid>
        <v-row>
          <v-col v-for="card in cards" :key="card" cols="12">
            <v-card>
              <v-subheader>{{ card }}</v-subheader>
              <v-list two-line>
                <template v-for="n in 6">
                  <v-list-item :key="n">
                    <v-list-item-avatar color="blue darken-1"> {{ card[0] }} {{n}}</v-list-item-avatar>
                    <v-list-item-content>
                      <v-list-item-title>Message {{ n }}</v-list-item-title>
                      <v-list-item-subtitle>
                        Subtitle Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil repellendus distinctio similique
                      </v-list-item-subtitle>
                    </v-list-item-content>
                  </v-list-item>
                  <v-divider v-if="n !== 6" :key="`divider-${n}`" inset></v-divider>
                </template>
              </v-list>
            </v-card>
          </v-col>
        </v-row>
     </v-container>


</template>

<script>
export default {
    name:"EmailList",
    components:{},
    data: () => ({
         cards: ['Today', 'Yesterday'],
    }),
    computed:{
    },
}
</script>