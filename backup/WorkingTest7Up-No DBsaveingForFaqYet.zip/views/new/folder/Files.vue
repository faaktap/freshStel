<template>
<!-- https://thewebdev.info/2020/08/15/vuetify%E2%80%8A-%E2%80%8Atable-footer-and-slots/
     https://thewebdev.info/2020/08/15/vuetify%e2%80%8a-%e2%80%8atable-checkbox-and-filtering/
:footer-props="{showFirstLastPage: true,firstIcon: 'mdi-arrow-collapse-left',lastIcon: 'mdi-arrow-collapse-right',4con: 'mdi-minus',nextIcon: 'mdi-plus'}"

:item-class="itemRowBackground" -> this does not want to work, should pass class back depending on an if statement
https://stackoverflow.com/questions/57961043/how-does-one-style-a-specific-row-on-v-data-table-vuetify
 -->
<div>
 <v-row>
  <v-col cols="12">
    <small class="text-caption green--text"> {{ localData.filename }} </small>
  </v-col>
  </v-row>

      <!-- <template v-slot:[`item.checkbox`]="{ item }">  -- still need a value
        <v-simple-checkbox v-model="item.size" disabled></v-simple-checkbox>
      </template> -->
      <!-- <template  v-slot:[`body.append`]="{ headers }">
        <tr>
          <td :colspan="headers.length">This is an appended row</td>
        </tr>
      </template> -->

    <v-data-table
      v-if="displayTable"
      :hide-default-header="true"
      class="text-sm-caption"
      :dense="$vuetify.breakpoint.smAndDown"
      :headers="selectedHeaders"
      :items="tableItems"
      :items-per-page="50"
      :loading="loading"
      :custom-sort="customSort"
      mobile-breakpoint="0"
      @click:row="rowClick"
      @dblclick:row="rowDblClick"
      items-per-page-options="-1"
      hide-default-footer
    >
     <!-- <template v-slot:item="{item, on, attrs}">
       <tr> :class="{active: group && item.id == group.id}">
       <td>  {{ item }} <br> {{ on }} {{ attrs }} </td>
       </tr>
      </template> -->
      <template #[`item.icon`]="{ item }">
        <v-icon
          title="Click on icon to 'play' the file"
          :color="item.color"
          :large="checkSelected(item)"
          @click.stop="clickIcon(item)"
        >
          {{ item.icon }}
        </v-icon>
      </template>
      <template #[`top`] v-if="!$vuetify.breakpoint.smAndDown">
        <base-bread
          v-if="curDir"
          :item="curDir"
          divider="/"
          :ignore-dir="ignoreDir"
          class="mb-1 pb-1"
          @changeFolder="$emit('changeFolder')"
        />
      </template>
      <template #[`header`]>
        <v-layout row wrap align-content-start justify-space-around class="ma-0 pa-0">
        <v-select
          v-if="headers && showColChange"
          class="text-caption caption blue--text"
          v-model="headerValue"
          :items="headers"
          multiple
          color="blue"
          return-object
          deletable-chips
          xhide-selected
          small-chips
          filled
          dense
          no-data-text="Click on a chip to delete one"
        />
        <v-btn x-small text @click="displayTable = !displayTable" title="change display Type">
          <template v-if="displayTable"> thumbs </template>
          <template v-else> names </template>
        </v-btn>
        <v-btn x-small text @click="showColChange = !showColChange" title="change column entries">
          <template v-if="showColChange"> hide column selector </template>
          <template v-else> columns  </template>
        </v-btn>
        </v-layout>
      </template>
      <template #[`no-data`]>
        NO FILES HERE - See folders on lefthand side!
      </template>

    </v-data-table>
    <template v-else>
      <v-btn x-small text @click="displayTable = !displayTable" title="change display Type"> Files </v-btn>
      <v-layout row wrap align-content-start justify-space-around class="ma-0 pa-0">
      <v-card v-for="t in tableItems" :key="t.filename"
              @click="$emit('clickIcon', t)"
              class="ma-1">
        <!-- 012345678901234567890123456 on /home/kuilieso/public_html/ -->
        <!-- <v-img :src="'https://kuiliesonline.co.za' + t.dirpath.substring(26) + '/' + t.filename" -->
        <v-img :src="thumbLookup + t.dirpath.substring(26) + '/' + t.filename"
                width="300"  cover
                :title="t.filename"
        />
        <span class="text-caption"> {{ t.filename }} </span>
         <!-- {{ thumbLookup + t.dirpath.substring(26) + '/' + t.filename }} -->
      </v-card>
      </v-layout>

    </template>

  </div>
</template>

<script>
import { feh } from '@/views/new/FolderEdit.js'
import BaseBread from '@/views/new/base/BaseBread.vue'
export default {
  name: 'Files',
  components: {
    BaseBread
  },
  props: ['fileDisplayRecords', 'curDir', 'ignoreDir', 'showFolders', 'moving', 'loading'],
  data: () => ({
    localData: '',
    headerValue: [],
    headers: [
      { text: 'type', value: 'icon', filterable: true },
      { text: 'Name', value: 'filename' },
      { text: 'size', align: 'start', value: 'size' },
      { text: 'date', align: 'start', value: 'modtime' }
      // { text: 'action', value: 'realsize' },
      // { text: 'checkbox' }
      // { text: "Requested", value: "requested", sort: (a, b) => a.localeCompare(b) },
    ],
    selectedHeaders: [],
    showColChange:false,
    displayTable: true,
    thumbLookup: 'https://kuiliesonline.co.za/api/thumb/?name='

  }),
  computed: {
    tableItems () {
      // this.$cs.l('computed - tableItems', this.showFolders, this.fileDisplayRecords)
      let answer = []
      if (this.showFolders) {
        return this.fileDisplayRecords
      } else {
        answer = this.fileDisplayRecords.filter(e => e.dir === false)
      }
      return answer
    },
    comHeaders () {
      return this.headers
    }
  },
  methods: {
    itemRowBackground: function (item) {
      // add this to v-data-table : :item-class="itemRowBackground"
       this.$cs.l('itemRowBackground',item)
       return '';  //item.protein > 4.2 ? 'style-1' : 'style-2'
    },
    checkSelected (item) {
      // this.$cs.l('check selected')
      // Check if we should highlight or mark this in some other way
      if (this.moving.some(ele => ele.modtime === item.modtime && ele.filename === item.filename)) {
        item.icon = 'mdi-marker-check'
        item.color = 'green'
        item.selected = true
        return true
      }
      if (item.icon === 'mdi-marker-check') {
        [item.icon, item.color] = feh.getExtensionInfo(item.ext)
        // this.$cs.l('unsel', item.icon, item.oldIcon)
        item.selected = false
      }
      return false
    },
    rowClick (e) {
      // this.$cs.l('click')
      // user clicked on a row, send it back to parent
      this.localData = e
      this.$emit('clickRow', e)
      // we need the hostname as well .. window.open(e.dirpath + '/' + e.filename, '_ddd')
    },
    rowDblClick (e) {
      // this.$cs.l('dblclick icon')
      // user dbl clicked on a row, send it back to parent
      this.localData = e.item
      this.$emit('clickDblRow', this.localData,e)
      // we need the hostname as well .. window.open(e.dirpath + '/' + e.filename, '_ddd')
    },

    clickIcon (e) {
      // this.$cs.l('click icon')
      // user clicked on a row icon , send it back to parent
      this.$emit('clickIcon', e)
    },
    customSort (items, index, isDesc) {
      // this.$cs.l('custom sort')
      // Date sort and size sort should be handled hear. Only datesort now fixed.
      // this.$cs.l(items, index, isDesc)
      items.sort((a, b) => {
        if (index === 'modtime') {
          if (!isDesc) {
            return a.realmodtime < b.realmodtime ? -1 : 1
          } else {
            return b.realmodtime < a.realmodtime ? -1 : 1
          }
        } else if (!isDesc) {
          return a[index] < b[index] ? -1 : 1
        } else {
          return b[index] < a[index] ? -1 : 1
        }
      })
      // this.$cs.l('custom sort', items)
      return items
    }
  },
  mounted () {
    // this.$cs.l('mounted:', this.$options.name, this.headers)
    this.headerValue.push(this.headers[0])
    this.headerValue.push(this.headers[1])
    this.headerValue.push(this.headers[3])
  },
  watch: {
    headerValue (val) {
      // this.$cs.l('watch value', this.val)
      this.selectedHeaders = val
    }
  }
}
</script>

<style scoped>

</style>
