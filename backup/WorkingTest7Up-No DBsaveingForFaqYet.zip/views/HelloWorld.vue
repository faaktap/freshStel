<template>
<v-container fluid>
 <!-- Printing stundet numbers for photographs -->
 <!--
 <v-row  v-if="studentData.length">
   <v-col v-for="e in studentData"
         :key="e.studentid"
   >
    <v-card elevation="1">
      <v-row class="ma-0 pa-0">
       <v-col cols="12" class="ma-0 pa-0">
        <span class="text-h2"> {{ e.studentid }} </span>
       </v-col>
       <v-col cols="12" class="ma-0 pa-0">
        <span class="text-caption">
        {{ e.surname.substr(0,14) }},{{e.firstname.substr(0,4)}}.{{e.gclass}}
        </span>
       </v-col>
      </v-row>
    </v-card>
   </v-col>
 </v-row>
 -->


  <b>email,contactno,schoolno,studentsurname, studentname,parentsurname,parentname,gclass,date, time </b><br>
  <v-card v-for="d in quizData" :key="d.dateEntered">
    <br> {{ d.schoolno || 0}}, {{ d.surname}}, {{ d.name }}, "{{d.gclass }}", {{d.parentsurname }}, {{ d.parentname }},{{ d.email }}, "{{d.contactno}}",{{d.date}}, {{d.time}}
  </v-card>

     <!-- <v-card>
     <v-card-title> Attendance Information Needed </v-card-title>
     <v-card-text>
      <v-row><v-col cols="8">
       <v-combobox
        v-model="responsiblePerson"
        :items="staffList"
        label="Responsible Person"
        outlined
        dense
        @click.once="userSelectedSomething"
       />
       <v-combobox
        v-model="location"
        :items="locationList"
        label="Location (free entry)"
        title="You can add new room here"
        outlined
        dense
        @click.once="userSelectedSomething"
       />

       <v-combobox
        v-model="period"
        :items="periodList"
        label="Period"
        outlined
        dense
        prepend-icon="mdi-timetable"
        append-icon="mdi-magnify"
        @click:prepend="showRooster = true"
        @click:append="showRooster = true"
        @click.once="userSelectedSomething"
       />
       </v-col><v-col cols="4">
         Some Info about selection
         </v-col></v-row>

     </v-card-text>
     <v-card-actions v-if="location && period && responsiblePerson && sessionID">
        <v-btn @click="startCapture"> Continue </v-btn>
        <small> ( {{ menemonic }} )</small>
     </v-card-actions>
   </v-card> -->


  <v-row style="background-color:LightGreen;" class="pa-4 ma-4">
        <v-chip @click="start(0)" v-show="selItem.length >= 1" > {{ selItem[0] }} </v-chip>
        <v-chip v-show="selItem.length >= 2" > {{ selItem[1] }} </v-chip>
        <v-chip v-show="selItem.length >= 3" > {{ selItem[2] }} </v-chip>
        {{selItem.length}} >= 1 -> {{ selItem.length >= 1 }} <br>
        selItem.length >= 2 -> {{ selItem.length >= 2 }} <br>
        selItem.length >= 3 -> {{ selItem.length >= 3 }}
        {{ subject.length}}
  </v-row>


 <v-row>
  <v-col cols="12">
   <v-card class="ma-2" id="printMe">
    <v-card-title class="noprint"> Select stuff </v-card-title>
     <v-data-table :headers="headers" :items="showData"
                 :loading="loading"
                 class="elevation-1"
                 :disable-items-per-page="true"
                 page-text="Sdfsdfsdf"
                 :disable-pagination="true"
                 :hide-default-footer="true"
                 @click:row="selectItem">
      <template v-slot:[`top`]>
        <base-search v-model="searchString" @clear="searchString=''" />
            selItem : {{ selItem }} <br>  {{ selItem.length }} <br>Current:  {{ current }}
      </template>
     </v-data-table>
     {{ grade }}
     <br>{{ items }}
   </v-card>
  </v-col>
 </v-row>
</v-container>
</template>

<script>
import { getters } from "@/api/store";
import { zmlFetch } from '@/api/zmlFetch';
import baseSearch from "@/components/base/baseSearch.vue"

//import { g10 } from '@/components/vfbase/Grade10List.js';

export default {
  name: "HelloWorld",
  components:{
    baseSearch
  },
  data: () => ({
    getZml: getters.getState({ object: "gZml" }),
    loading: false,
    current: '',
    searchString:'',
    teachers:[],
    teachersHead:[{text:'teacher', value:'teacher'},{text:'count', value:'count'}],
    grade:[],
    gradeHead:[{text:'grade', value:'grade'},{text:'count', value:'count'}],
    subject:[],
    subjectHead:[{text:'subject', value:'subjectname'},{text:'count', value:'count'},{text:'From', value:'gc1'},{text:'To', value:'gc2'}],
    items:[],
    headers:[],
    selItem:[],
    quizData:[],
    studentData:[],
  }),
  computed: {
    showData() {
        if (this.searchString == '') return this.items || []
        if (this.current == 'teachers')
           return this.items.filter(e => e.teacher.toLowerCase().includes(this.searchString.toLowerCase()) )
        if (this.current == 'grade')
           return this.items.filter(e => e.grade.toLowerCase().includes(this.searchString.toLowerCase()) )
        if (this.current == 'subject')
           return this.items.filter(e => e.subjectname.toLowerCase().includes(this.searchString.toLowerCase()) )

        return this.items || []

    }
  },
  watch: {
  },
  created() {
    this.loadTeacher();
    //g10.getAllQuiz('all',this.loadData)
    //this.loadStudent();
  },
  methods: {
    loadStudent() {
        this.loading = true
        let ts = {task: 'PlainSql',
               sql: `SELECT studentid, surname,firstname,grade,gclass from dkhs_student where grade = 'G08' order by surname, firstname, gclass`
             }
        zmlFetch(ts, this.loadStudentData)
    },
    loadStudentData(response) {
      this.studentData = response
    },
    loadData(response) {
        if (response == "[null]") {
          alert('No Data Yet!')
          return
        }
        this.quizData = JSON.parse( response )
        //2023-01-19T15:57:57.205Z
        this.quizData.forEach(e => {
          e.date = e.dateEntered.substring(0,10)
          e.time = e.dateEntered.substring(11,19)
        })
      },
    start(selNo) {
      this.searchString = ''
      if (selNo == 0) {
        this.selItem = []
        this.current = ''
        this.loadTeacher()
      }
    },
    selectItem(e1,e2) {
        console.log('select item : ', this.current,e2.item)
        switch(this.current) {
            case 'teachers':
                this.selItem.push(e2.item.teacher)
                this.loadGrade()
                break
            case 'grade':
                this.selItem.push(e2.item.grade)
                this.loadSubject()
                break
            case 'subject':
                this.selItem.push(e2.item.subjectname)
                this.loadStudents()
                break
            default:
                alert('case is not handling : ' + this.current)
        }
        console.log('select item DONE: ', this.current,this.selItem)

    },
    loadStudents() {
        console.log('load students,', this.selItem)


    },
    loadTeacher() {
        this.loading = true
        let ts = {task: 'PlainSql',
               sql: `SELECT teacher, count(*) count FROM dkhs_studsub group by teacher`
             }
        zmlFetch(ts, this.loadTeacherData)
    },
    loadTeacherData(response) {
        this.teachers = response
        this.doSwitch('teachers')
        this.loading = false
        console.log('teachers = ', response)
    },
    loadGrade() {
        this.loading = true
        let ts = {task: 'PlainSql',
               sql: `SELECT l.grade, count(*) count \
                     FROM dkhs_studsub s, dkhs_student l \
                     WHERE s.studentid = l.studentid \
                     and teacher = '${ this.selItem[0] }' \
                     group by l.grade`
             }
        zmlFetch(ts, this.loadGradeData)
    },
    loadGradeData(response) {
        this.grade = response
        this.doSwitch('grade')
        this.loading = false
        console.log('grade = ', response)
    },
    loadSubject() {
        this.loading = true
        let ts = {task: 'PlainSql',
               sql: `SELECT s.subjectname, s.ckey,min(gclass) gc1, max(gclass) gc2, count(*) count \
  FROM dkhs_studsub s, dkhs_student l \
  WHERE s.studentid = l.studentid \
  and teacher = '${ this.selItem[0] }' \
  and grade = '${ this.selItem[1] }' \
  group by s.subjectname, s.ckey`
             }
        zmlFetch(ts, this.loadSubjectData)
    },
    loadSubjectData(response) {
        this.subject = response
        this.doSwitch('subject')
        this.loading = false
        console.log('subject = ', response)
    },
    doSwitch(current) {
        console.log('do switch ', current)
        // We need to clear searchString for next batch
        this.searchString = ''
        switch(current){
            case 'teachers':
              this.items = this.teachers
              this.headers = this.teachersHead
              break
            case 'grade':
              this.items = this.grade
              this.headers = this.gradeHead
              break
            case  'subject':
              this.items = this.subject
              this.headers = this.subjectHead
              break
            default:
              alert('not the yet' + current)
        }
        this.current = current
    }

  },
}
</script>

<style scoped>
  .print-break-page {
       page-break-after: always;
  }

@media print {
  body {
    overflow: auto;
    height: auto;
  }
  .scroll-y {
     height: auto;
     overflow: visible;
  }
  .print-break-page {
       page-break-after: always;
  }

  /*
   * Note, forced page breaks are only for testing when content is insufficient
   */
  .page_content__print_break {
    page-break-after: always;
    break-after: always;
  }

  .footer_content {
    visibility: show;
    opacity: 1;
    filter: alpha(opacity=100);

    position: fixed;
    bottom: 0;
  }

  .footer_content::after {
    counter-increment: page_number;
    content: "Page:" counter(page_number);
  }
}
</style>