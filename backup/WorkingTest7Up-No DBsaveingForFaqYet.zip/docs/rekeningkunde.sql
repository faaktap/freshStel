insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "A14.7.pdf",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/A14.7.pdf",
        "file",12,17);
        
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "A14.9.pdf",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/A14.9.pdf",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "14.10 Part 1.mp4",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/14.10 Part 1.mp4",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "Budgets overview.mp4",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/Budgets overview.mp4",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "Grade 12 Ex 14.8 Debtors collection.mp4",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/Grade 12 Ex 14.8 Debtors collection.mp4",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "A14.5.pdf",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/A14.5.pdf",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "A14.2.pdf",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/A14.2.pdf",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "A14.6.pdf",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/A14.6.pdf",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "14.10 Part 3.mp4",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/14.10 Part 3.mp4",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "A14.4.pdf",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/A14.4.pdf",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "14.10 Part 2.mp4",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/14.10 Part 2.mp4",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "A14.10.pdf",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/A14.10.pdf",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "A14.3.pdf",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/A14.3.pdf",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "Question 6 November 2016.mp4",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/Question 6 November 2016.mp4",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "A14.8.pdf",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/A14.8.pdf",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "Overview.fbr",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/Overview.fbr",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "Text book exercises - calculations.xlsx",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/Text book exercises - calculations.xlsx",
"file",12,17);
insert into dkhs_lcontent (sortorder,name,description,type,grade,subjectid)values (1,
        "A14.1.pdf",
        "load:Subjects/GR12/Accounting_Rekeningkunde/Gr 12 - Mrs Wiegand/Budgets/A14.1.pdf",
"file",12,17);

