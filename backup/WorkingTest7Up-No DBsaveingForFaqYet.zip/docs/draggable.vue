Very nice package!!
https://www.npmjs.com/package/vuedraggable
