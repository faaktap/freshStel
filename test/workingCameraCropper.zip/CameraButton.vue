<template>
<!--
    I had a bit of difficulty converting the snapped image to a fileObject, so I can pass it to cropper.
    I changed cropper to allow for a base64 image to be accepted, but then I had to change it to return a base64 image as well.
    Decided eventually to "prep" my snapped image to look like a file, called internal.png, and then pass that to cropper (cropstart)
     then when I receive it back, it is a file object as well, which would make it the same as all my other uploaded files.
    I am still not sure of what everything do, but it's working
    Next step is to clean up, and show two buttons, one for camera and one for "gallery" or folder.
     Then user can either use his webcam (here) or have a standard file select interface.
    -->
 <v-container class="ma-0 pa-0">
<!-- <v-img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAADAFBMVEUAAAD7PwD+RAD+QwD9QwD+RQD7OQD/RQD8PwD/RgD/QgD3NwD0NgDGJAD+RgD+QgD/RAD7QQD+QQD+RAD+RAD+QwD9QwD9QwD+QwD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+QwD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+QgD+RAD+RAD+RQD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD/RQD+RAD+RAD/RQD+RAD+RAD+RAD+RAD+RAD/RQD+RAD/RQD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD9QwD+RAD/RQD+QwD+RAD+RAD+QwD+RAD/RQD/RQD+RAD+RAD+RAD+RAD+QwD+RAD/RQD/RQD+RAD+RAD+RAD+RAD+QwD+RAD/RQD+RAD/RQD/RQD+RAD+QwD+RAD+RAD+RAD/RQD+RQD/RQD/RQD+RQD/RQD/RQD+RAD/RQD+RAD+RAD+RAD+RAD+RQD+RAD+RQD+RAD+RAD/RQD+RAD+RAD+RAD9QwD+RAD+RAD+QwD+RAD/RQD+RAD+RAD/RQD+RAD9QwD+RAD+RAD+QwD3PgD+RAD+RAD9QgD+RAD+RAD9QwD+RAD+RAD/RAD+RADzPgD7QQD+RAD+RAD+RAD+RAD+RAD+QwD+RQD+RAD+RAD+RAD+RAD+RAD+RQD+RAD+RQD+RAD+RAD9QQD+RAD+RAD9QwD+RAD+RAD9QwD+RAD+RAD+RAD+RAD+RAD+QwD9QwD+RAD+RAD+RAD+QwD/RQD/RQD+RAD/RAD/RQD+RAD8QQD+RAD+RAD+QwD+QwD+RAD+RAD+RAD+RAD+RAD+RAD+QwD+RAD+RAD+RQD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RAD+RQD+QwD+RQD+RAD9QgD+RQD+RAD+RAD+RAD+RAD+RAD+RAD/RQD+RQD///9zLoyQAAAA/XRSTlMAAAAAAAAAAAAAAAAAAAAAAAAACjAOAQUBJWeIfGqp5VQZbmwHPapoCShjLAFS2v48xBLA920Vu95JLt9hVuHzOXH923fNHIb+vPVAFtZ53S3gaw7C6RzI1Rge4Pzux7S2CiLd2BdE0nMEi+Ir5uUqAhgIJPjp+vnq+/ZT57I4B4InhyiXdt/srVADrEYX0fdDKeOREvWFCAGkRQSvQgmjk/ZZAQKooKfqtwkC66IDnuaZjw8EswOrfwaxuAxgJy8g3BMLUU/BD/LwOtTxpgOEBRYb0LqM1LnnBpWS4u/j+Nji9PHwvxNppSNNgQYzPjI2eyNyoQJnZvJBNU4BqI2cNgAAAAFiS0dE/6UH8sUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAHdElNRQfjBgQRJQ85jqVKAAACqklEQVQ4y33Sd1xNcRQA8J/zup5nj4qQBu81rBLKSyjUa1AySlIyKqOMIonskZJIyCoZZe+RkT3KygjJDFnJXnF8nN998fE+H975457f5/y+99x7f/cwJkYlqKerJ1GvdfTr61csxZA0MGjYqLFhEyNjAMHEtGkzkCvMzEEiWFg2b0EQKrds1Rp5mEqrWFmjkUEbG2zbTgbtbX/adQBgoLRHdXQUHDohdu7i6ITY1UDajVJ3Z2AyF0SVq6sK3dw9ehBz6+nJtaNXL7qqvIH17oPY16ufD/r29xtANf+BKg4CAsWug4LY4CGIQ4dBcEioMHwE/gmVyHDkKKYMQwwfDWPGjgOI4C0ix0/gW1ETo+k6KYYpJxOfEjtVqMogyIbW06bPoC2Vy8xZvNFsFjGH+7nz4qjD/HhqkAALEhEXJsGixbSRzJb4qB+asnSZZHkqgRWwchWB1bDGlspprFp6xWutzYB1aSJYv0HsUH0jVTMZyLMqxKbNNSpAJoFgkKWLQNhiuFUNwixkmiCZitvoZ2y32rGTg8gETSDdRcXdTDDfI+zV3UdrpwxNsP+A+JlgebBmLfAKJ2GpCfQCKBmz7EOHs0FyxJrAUU2QQzeFHWPHT4ScBDhFvyz69N8gCc7QkZ89x4LP5+YBeFxAvBgruySe5GUFd1KaA7wiY97+qHDOd3BD9L167Tq9liH4hfCUfQMx1wpYAY3AzVu3+bEX3uFfm2hRJKYkmoPAIAlL/T0B9socztCp6C5P/opcjMqgmczEe/cfUMuHcaB8lFJcXPw42ZOnJ0+jMKAEGHv23P3Fy1cFZhE6UPq6TC4vy/N4w9Pbd6gyFWjs8wtr12H/CGko2r0H9v+QfsCPn7QB+IxfoK42EPP1m7YGDMqzvmsHJfHl2sEPk1IOfgETbte29wGhIgAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxOS0wNi0wNFQxNzozNzoxNSswMjowMDImJ38AAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTktMDYtMDRUMTc6Mzc6MTUrMDI6MDBDe5/DAAAAGHRFWHRTb2Z0d2FyZQBwYWludC5uZXQgNC4xLjb9TgnoAAAAV3pUWHRSYXcgcHJvZmlsZSB0eXBlIGlwdGMAAHic4/IMCHFWKCjKT8vMSeVSAAMjCy5jCxMjE0uTFAMTIESANMNkAyOzVCDL2NTIxMzEHMQHy4BIoEouAOoXEXTyQjWVAAAAAElFTkSuQmCC"
width="100"/> -->
<v-img v-if="croppedImgSrc" :src="croppedImgSrc" width="100"/>

    <h1> Test </h1>


    <v-btn class="ml-2 mb-1" small @click="showDone = !showDone"> <v-icon small> mdi-thumb-up</v-icon>    Done    </v-btn>
    <v-card class="ma-0 pa-0">
        <v-card-text  v-if="showDone == false" >
          <v-card>
           <video v-if="!imageData" ref="video" class="camera-stream" title="Video Stream"/>
           <v-img v-else :src="imageData" class="camera-stream" contain title="Snapped Image"/>
          </v-card>
        </v-card-text>
        <v-card-actions v-if="showDone == false">
            <v-layout row wrap align-content-center justify-space-between>
            <v-btn class="ml-2 mb-1" small @click="captureImage" color="primary"><v-icon small>mdi-camera</v-icon>       Snap </v-btn>
            <v-btn class="ml-2 mb-1" small @click="showDone = true"> <v-icon small> mdi-thumb-up</v-icon>    Done    </v-btn>
            <v-btn class="ml-2 mb-1" small @click="cancelImage" color="warning"> <v-icon small>mdi-cancel</v-icon>       Cancel  </v-btn>
            </v-layout>
        </v-card-actions>
   <v-btn class="ma-2"  @click="showImageData"> showImageData </v-btn>
   <v-btn class="ma-2"  @click="activateAvatarUpload = !activateAvatarUpload"> activateAvatar = {{ activateAvatarUpload }} </v-btn>
   <v-btn class="ma-2" @click="playWithFile"> playWithFile </v-btn>
    </v-card>
    <crop-start v-if="activateAvatarUpload"
       :image="fileObj"
       @done="(image) => {if (image) {form.image=image; setImage(form.image)}}"
    />
 </v-container>


</template>

<script>
import CropStart from "@/stel/CropStart.vue";
export default {
    name: "CameraButton",
    components: {CropStart},
    data: () => ({
            defaultImage: '/img/learner.png',
            mediaStream: null,
            fileObj:null,
            form:{
                image:null
            },
            croppedImgSrc: '',
            imageData:'',
            showDone:false,
            activateAvatarUpload: false,
    }),

    methods: {
       async dataURLToFile(imageString, filename, mimeType) {
        const res = await fetch(imageString)
        const blob = await res.blob()
        return new File([blob], filename, { type: mimeType })
       },
       async playWithFile() {
          this.fileObj = await this.dataURLToFile(this.imageData, 'internal.png', 'data:image/png;base64')
          console.log('playwithfile:', this.fileObj)
       },
       setImage(file) {
          if (!file.type.includes("image/")) {
            alert("Please select an image file");
            return;
          }
          if (typeof FileReader === "function") {
            const reader = new FileReader();
            reader.onload = (event) => {
              this.croppedImgSrc = event.target.result;
            };
            reader.readAsDataURL(file);
          } else {
            alert("Sorry, FileReader API not supported");
          }
        },
        captureImage() {
            const mediaStreamTrack = this.mediaStream.getVideoTracks()[0]
            const imageCapture = new window.ImageCapture(mediaStreamTrack)
            let reader = new FileReader();
            return imageCapture.takePhoto().then(blob => {
                reader.readAsDataURL(blob)
                reader.onload = () => {
                    this.imageData = reader.result;
                }
            })
        },
        cancelImage() {
            this.imageData = null;
            this.showCameraModal = true;
            navigator.mediaDevices.getUserMedia({video: true})
            .then(mediaStream => {
                    this.$refs.video.srcObject = mediaStream;
                    this.$refs.video.play()
                    this.mediaStream = mediaStream
            })
        },
        uploadImage() {
            alert('image upload : ' + this.imageData.length)
            // axios({ method: "POST", "url": API_IMAGE_ENDPOINT, "data": this.imageData})
            //         .then(response => {
            //             this.response = response.data;
            //          })
        },
        playWithBlob() {
            // create Blob from a string
            let blob1 = new Blob(["<html>..stuff..</html>"], {type: 'text/html'});
            // please note: the first argument must be an array [...]
            // create Blob from a typed array and strings
            let hello = new Uint8Array([72, 101, 108, 108, 111]); // "Hello" in binary form
            let blob2 = new Blob([hello, ' ', 'world'], {type: 'text/plain'})
            /*
            blob2.slice([byteStart], [byteEnd], [contentType]);
               byteStart – the starting byte, by default 0.
               byteEnd – the last byte (exclusive, by default till the end).
               contentType – the type of the new blob, by default the same as the source.
            */

            console.log('play with blob', blob1, blob2, hello)
        },
        showImageData() {
            console.log('showImageData', this.fileObj)
        },
    },
    mounted() {
        navigator.mediaDevices.getUserMedia(
            { video: {
                 minAspectRatio: 1.333,
                 minFrameRate: 60,
                 width: 640,
                 heigth: 480
              }
            })
            .then(mediaStream => {
                    this.$refs.video.srcObject = mediaStream;
                    this.$refs.video.play()
                    this.mediaStream = mediaStream
            })
    },
    watch:{
        imageData() {
           this.playWithFile()
        }
    }
}
</script>

<style>
    .camera-icon {
        width: 15%;
        vertical-align: middle;
        margin: auto;
    }
    .camera-stream {
        width: auto;
        max-height: 400px;
        max-width: 400px;
        object-fit: cover;
    }
</style>